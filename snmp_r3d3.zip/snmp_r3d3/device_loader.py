
import importlib.util
import pkgutil
import pathlib
import logging
from typing import Dict, Any

_LOGGER = logging.getLogger(__name__)

def load_devices() -> Dict[str, Dict[str, Any]]:
    """Load device definitions from ./devices (relative to this file)."""
    devices: Dict[str, Dict[str, Any]] = {}

    # Path to ./devices relative to this file
    devices_path = pathlib.Path(__file__).parent / "devices"

    for m in pkgutil.iter_modules([str(devices_path)]):
        if m.name.startswith("_"):
            continue

        try:
            # Load module dynamically from ./devices
            spec = importlib.util.spec_from_file_location(
                m.name, devices_path / f"{m.name}.py"
            )
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)  # type: ignore
        except Exception as e:
            _LOGGER.error("Failed to import device module '%s': %s", m.name, e)
            continue

        sections = {}
        for section in ["config", "attributes", "device", "ports"]:
            if hasattr(mod, section):
                sec = getattr(mod, section)
                if not isinstance(sec, dict):
                    _LOGGER.error("Device '%s' section '%s' must be a dict, skipping file", m.name, section)
                    break
                sections[section] = sec

        # Required sections
        for required in ["config", "attributes", "device"]:
            if required not in sections:
                _LOGGER.error("Device '%s' missing required section '%s', skipping file", m.name, required)
                break
        else:
            # Validate config has access_test_oid
            config = sections["config"]
            if "access_test_oid" not in config or not isinstance(config["access_test_oid"], str):
                _LOGGER.error("Device '%s' config missing mandatory key 'access_test_oid', skipping file", m.name)
                continue

            if m.name in devices:
                _LOGGER.error("Duplicate device filename '%s', skipping file", m.name)
                continue

            devices[m.name] = sections
            _LOGGER.info("Loaded device definition: %s", m.name)

    return devices
